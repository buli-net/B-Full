/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Cannot be updated, the Kt name has been released
@file:Suppress("FacadeClassJvmName", "NOTHING_TO_INLINE")

package androidx.core.graphics

import android.graphics.Paint

/**
 * Convenience method to configure the BlendMode of a Paint in a backward compatible way. This
 * method is a no-op for BlendModes that have no equivalent on older API levels
 */
public inline fun Paint.setBlendMode(blendModeCompat: BlendModeCompat?): Boolean {
    return PaintCompat.setBlendMode(this, blendModeCompat)
}
