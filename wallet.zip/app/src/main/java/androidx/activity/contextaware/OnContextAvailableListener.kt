/*
 * Copyright 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.activity.contextaware

import android.content.Context

/**
 * Listener for receiving a callback at the first moment a [Context] is made available to the
 * [ContextAware] class.
 *
 * @see ContextAware.addOnContextAvailableListener
 */
public fun interface OnContextAvailableListener {
    /**
     * Called when the [ContextAware] object this listener was added to is associated to a
     * [Context].
     *
     * @param context The [Context] the [ContextAware] object is now associated with.
     */
    public fun onContextAvailable(context: Context)
}
